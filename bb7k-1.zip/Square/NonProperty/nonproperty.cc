#include "nonproperty.h"
NonProperty::NonProperty(Board *theBoard, TextDisplay * td): Square(theBoard, td){}